import os
import colorama
from colorama import Fore, init, Style


banner = f"""{Fore.LIGHTMAGENTA_EX}

         ███▄    █  ██▓▄▄▄█████▓ ██▀███   ▒█████      ██▓███   ██▀███   ▒█████   ███▄ ▄███▓ ▒█████  
         ██ ▀█   █ ▓██▒▓  ██▒ ▓▒▓██ ▒ ██▒▒██▒  ██▒   ▓██░  ██▒▓██ ▒ ██▒▒██▒  ██▒▓██▒▀█▀ ██▒▒██▒  ██▒
        ▓██  ▀█ ██▒▒██▒▒ ▓██░ ▒░▓██ ░▄█ ▒▒██░  ██▒   ▓██░ ██▓▒▓██ ░▄█ ▒▒██░  ██▒▓██    ▓██░▒██░  ██▒
        ▓██▒  ▐▌██▒░██░░ ▓██▓ ░ ▒██▀▀█▄  ▒██   ██░   ▒██▄█▓▒ ▒▒██▀▀█▄  ▒██   ██░▒██    ▒██ ▒██   ██░
        ▒██░   ▓██░░██░  ▒██▒ ░ ░██▓ ▒██▒░ ████▓▒░   ▒██▒ ░  ░░██▓ ▒██▒░ ████▓▒░▒██▒   ░██▒░ ████▓▒░
        ░ ▒░   ▒ ▒ ░▓    ▒ ░░   ░ ▒▓ ░▒▓░░ ▒░▒░▒░    ▒▓▒░ ░  ░░ ▒▓ ░▒▓░░ ▒░▒░▒░ ░ ▒░   ░  ░░ ▒░▒░▒░ 
        ░ ░░   ░ ▒░ ▒ ░    ░      ░▒ ░ ▒░  ░ ▒ ▒░    ░▒ ░       ░▒ ░ ▒░  ░ ▒ ▒░ ░  ░      ░  ░ ▒ ▒░ 
           ░   ░ ░  ▒ ░  ░        ░░   ░ ░ ░ ░ ▒     ░░         ░░   ░ ░ ░ ░ ▒  ░      ░   ░ ░ ░ ▒  
                 ░  ░              ░         ░ ░                 ░         ░ ░         ░       ░ ░  
{Fore.MAGENTA}
                            ____________________________________________
                            |                                          |
                            |                                          |
                            |             Tools made by                |
                            |                  and 1AM                 |  
                            |             < Nitro Promo Gen >          |
                            |                                          |
                            |__________________________________________|


"""

print(banner)







import requests
import random
from faker import Faker
import uuid
import tls_client
from datetime import datetime
from concurrent.futures import ThreadPoolExecutor

# Initialisiere Faker und Colorama
fake = Faker()
init(autoreset=True)

# Logging Funktion mit Farbunterstützung und Zeitstempel
def log(tag, content, color):
    ts = datetime.now().strftime('%H:%M:%S')
    print(f"{Style.BRIGHT}{Fore.BLACK}[{ts}] {color}[{tag}] {Fore.WHITE}{content}{Style.RESET_ALL}")

# Benutzer-Eingabe für Anzahl Promos und Threads
s, f = 0, 0
amt = int(input(f"{Style.BRIGHT}{Fore.LIGHTMAGENTA_EX}# {Fore.WHITE}Combien de promotions générer/récupérer {Fore.LIGHTMAGENTA_EX}> {Fore.WHITE}"))
thd = int(input(f"{Style.BRIGHT}{Fore.LIGHTMAGENTA_EX}# {Fore.WHITE}Exécuter combien de fils de discussion  {Fore.LIGHTMAGENTA_EX}> {Fore.WHITE}"))
print()

# Funktion, die eine Promo abruft
def getpromo(proxy):
    global s, f
    name = (fake.first_name() + fake.last_name()).lower()
    session = tls_client.Session(client_identifier="chrome_128")
    
    headers = {
        "accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7",
        "accept-language": "en-US,en;q=0.9",
        "cache-control": "max-age=0",
        "priority": "u=0, i",
        "referer": "https://www.chess.com/friends?name=joseph",
        "sec-ch-ua": '"Chromium";v="128", "Not;A=Brand";v="24", "Microsoft Edge";v="128"',
        "sec-ch-ua-mobile": "?0",
        "sec-ch-ua-platform": '"Windows"',
        "sec-fetch-dest": "document",
        "sec-fetch-mode": "navigate",
        "sec-fetch-site": "same-origin",
        "sec-fetch-user": "?1",
        "upgrade-insecure-requests": "1",
        "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36",
    }
    
    # Abfrage von UUID
    try:
        response = session.get(f"https://www.chess.com/member/{name}", headers=headers, proxy={"http": f"http://{proxy}", "https": f"http://{proxy}"})
        user_uuid = response.text.split('data-user-uuid="')[1].split('"')[0]
        log("UUID", f"Success: UUID retrieved -> {user_uuid} ({name})", Fore.BLUE)
    except Exception as e:
        log("UUID", f"Error when retrieving the UUID for {name} -> {str(e)}", Fore.RED)
        return
    
    # Anfrage für Promo-Code
    headers["accept"] = "application/json, text/plain, */*"
    headers["content-type"] = "application/json"
    json_data = {
        "userUuid": user_uuid,
        "campaignId": "4daf403e-66eb-11ef-96ab-ad0a069940ce",
    }
    
    try:
        response = session.post(
            "https://www.chess.com/rpc/chesscom.partnership_offer_codes.v1.PartnershipOfferCodesService/RetrieveOfferCode",
            headers=headers,
            json=json_data,
            proxy={"http": f"http://{proxy}", "https": f"http://{proxy}"}
        )
        
        code = 'https://promos.discord.gg/' + response.json()["codeValue"]
        s += 1
        log("PROMO", f"Success: Promo received -> {code} [In total: {s} Promos]", Fore.GREEN)
        with open('codes.txt', 'a') as f:
            f.write(code + '\n')
    except Exception as e:
        log("ERR", f"Error when retrieving the promo -> {str(e)}", Fore.RED)

# Laden der Proxy-Liste
with open('proxies.txt', 'r') as f:
    proxies = f.read().splitlines()

# Ausführung der Promo-Abfrage mit mehreren Threads
with ThreadPoolExecutor(max_workers=thd) as executor:
    for i in range(amt):
        proxy = random.choice(proxies)
        executor.submit(getpromo, proxy)
pass
#--------------------------------------------------------------------
if choice =='5':
 print(Fore.GREEN + (banner))
with open('codes.txt'):
 print("You have"(s)+"Nitro promo codes !!!")